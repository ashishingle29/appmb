(()=>{var e={};e.id=475,e.ids=[475],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},21064:(e,t,r)=>{"use strict";r.d(t,{A:()=>n});var a=r(56037),i=r.n(a);let s=new(i()).Schema({title:{type:String,required:!0},slug:{type:String,required:!0},category:{type:i().Schema.Types.ObjectId,ref:"category",default:null},tags:[{type:i().Schema.Types.ObjectId,ref:"tags",default:[]}],content:{type:i().Schema.Types.Mixed,default:{}},isPublished:{type:Boolean,default:!1},isDeleted:{type:Boolean,default:!1},featuredImage:{type:String,default:null},metadescription:{type:String,default:""}},{timestamps:!0}),n=i().models.Post||i().model("Post",s)},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},40810:(e,t,r)=>{"use strict";r.d(t,{A:()=>n});var a=r(56037),i=r.n(a);let s=new(i()).Schema({name:{type:String,required:!0,unique:!0},slug:{type:String,required:!0,unique:!0},description:{type:String,required:!0},image:{type:String,required:!0},isDeleted:{type:Boolean,default:!1}},{timestamps:!0}),n=i().models.category||i().model("category",s)},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55172:(e,t,r)=>{"use strict";r.d(t,{A:()=>n});var a=r(56037),i=r.n(a);let s=new(i()).Schema({name:{type:String,required:!0,unique:!0},slug:{type:String,required:!0,unique:!0},isDeleted:{type:Boolean,default:!1}},{timestamps:!0}),n=i().models.tags||i().model("tags",s)},56037:e=>{"use strict";e.exports=require("mongoose")},56649:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>A,routeModule:()=>f,serverHooks:()=>q,workAsyncStorage:()=>w,workUnitAsyncStorage:()=>x});var a={};r.r(a),r.d(a,{GET:()=>h});var i=r(96559),s=r(48088),n=r(37719),o=r(32190),l=r(21064),u=r(40810),d=r(55172),p=r(94527);async function m(){return await (0,p.A)(),await l.A.find().select("slug updatedAt featuredImage title metadescription").sort({updatedAt:-1})}async function c(){return await (0,p.A)(),await u.A.find().select("slug updatedAt name image").sort({updatedAt:-1})}async function g(){return await (0,p.A)(),await d.A.find().select("slug updatedAt").sort({updatedAt:-1})}let y="https://appmb.org.in";async function h(){let e=await m(),t=await c(),r=await g(),a=`<?xml version="1.0" encoding="UTF-8"?>
`;return a+=`<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" 
                xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">

    <url>
      <loc>${y}</loc>
      <lastmod>${new Date().toISOString()}</lastmod>
      <changefreq>daily</changefreq>
      <priority>1.00</priority>
    </url>
  `,e.forEach(e=>{a+=`
      <url>
        <loc>${y}/blogs/${e.slug}</loc>
        <lastmod>${new Date(e.updatedAt).toISOString()}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.90</priority>
        ${e.featuredImage?`
          <image:image>
            <image:loc>${y}${e.featuredImage}</image:loc>
            <image:title>${e.title}</image:title>
            <image:caption>${e.metadescription}</image:caption>
           </image:image>`:""}
      </url>
    `}),t.forEach(e=>{a+=`
      <url>
        <loc>${y}/categories/${e.slug}</loc>
        <lastmod>${new Date(e.updatedAt).toISOString()}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.80</priority>
        ${e.image?`
          <image:image>
            <image:loc>${y}${e.image}</image:loc>
            <image:title>${e.name}</image:title>
          </image:image>`:""}
      </url>
    `}),r.forEach(e=>{a+=`
      <url>
        <loc>${y}/tags/${e.slug}</loc>
        <lastmod>${new Date(e.updatedAt).toISOString()}</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.70</priority>
      </url>
    `}),a+="</urlset>",new o.NextResponse(a,{headers:{"Content-Type":"application/xml"}})}let f=new i.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/sitemap.xml/route",pathname:"/sitemap.xml",filename:"route",bundlePath:"app/sitemap.xml/route"},resolvedPagePath:"C:\\Users\\Ashish Ingle\\OneDrive\\Desktop\\AppMB\\appmb\\src\\app\\sitemap.xml\\route.js",nextConfigOutput:"",userland:a}),{workAsyncStorage:w,workUnitAsyncStorage:x,serverHooks:q}=f;function A(){return(0,n.patchFetch)({workAsyncStorage:w,workUnitAsyncStorage:x})}},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},94527:(e,t,r)=>{"use strict";r.d(t,{A:()=>o});var a=r(56037),i=r.n(a);let s="mongodb+srv://EduTechAshish:EduTechAshish@edutechhub.1vsmlfh.mongodb.net/appmb";if(!s)throw Error("Please define the MONGODB_URI environment variable");let n=global.mongoose||{conn:null,promise:null},o=async function(){return n.conn||(n.promise||(n.promise=i().connect(s,{connectTimeoutMS:3e4}).then(e=>e)),n.conn=await n.promise),n.conn}},96487:()=>{}};var t=require("../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[719,580],()=>r(56649));module.exports=a})();